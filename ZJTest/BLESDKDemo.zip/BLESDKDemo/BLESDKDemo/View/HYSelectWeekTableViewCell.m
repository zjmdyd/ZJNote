//
//  HYSelectWeekTableViewCell.m
//  KeerZhineng
//
//  Created by ZJ on 2018/12/24.
//  Copyright © 2018 HY. All rights reserved.
//

#import "HYSelectWeekTableViewCell.h"

@interface HYSelectWeekTableViewCell ()

@property (strong, nonatomic) IBOutletCollection(ZJSelectButton) NSArray *btns;

@end

@implementation HYSelectWeekTableViewCell

- (IBAction)btnEvent:(ZJSelectButton *)sender {
    sender.select = !sender.select;
    
    if ([self.delegate respondsToSelector:@selector(selectWeekTableViewCell:didSelectButton:)]) {
        [self.delegate selectWeekTableViewCell:self didSelectButton:sender];
    }
}

- (void)setValues:(NSArray *)values {
    _values = values;

    for (ZJSelectButton *btn in self.btns) {
        btn.select = [_values[btn.tag] boolValue];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    for (ZJSelectButton *btn in self.btns) {
        btn.selectImgName = @"ic_xuankuang_44x44-4";
        btn.unSelectImgName = @"ic_xuankuang_44x44";
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
