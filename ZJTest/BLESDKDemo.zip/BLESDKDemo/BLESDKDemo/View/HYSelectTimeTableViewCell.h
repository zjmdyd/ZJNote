//
//  HYSelectTimeTableViewCell.h
//  KeerZhineng
//
//  Created by ZJ on 2018/12/24.
//  Copyright © 2018 HY. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class HYSelectTimeTableViewCell;

@protocol HYSelectTimeTableViewCellDelegate <NSObject>

- (void)selectTimeTableViewCell:(HYSelectTimeTableViewCell *)cell didClickButtonAtIndex:(NSInteger)index;

@end

@interface HYSelectTimeTableViewCell : UITableViewCell

@property (nonatomic, weak) id<HYSelectTimeTableViewCellDelegate> delegate;
@property (nonatomic, strong) NSArray *values;

@end

NS_ASSUME_NONNULL_END
