//
//  HYSelectWeekTableViewCell.h
//  KeerZhineng
//
//  Created by ZJ on 2018/12/24.
//  Copyright © 2018 HY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJSelectButton.h"

NS_ASSUME_NONNULL_BEGIN

@class HYSelectWeekTableViewCell;

@protocol HYSelectWeekTableViewCellDelegate <NSObject>

- (void)selectWeekTableViewCell:(HYSelectWeekTableViewCell *)cell didSelectButton:(ZJSelectButton *)button;

@end

@interface HYSelectWeekTableViewCell : UITableViewCell

@property (nonatomic, weak) id<HYSelectWeekTableViewCellDelegate> delegate;

@property (nonatomic, strong) NSArray *values;

@end

NS_ASSUME_NONNULL_END
