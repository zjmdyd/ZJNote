//
//  HYSelectTimeTableViewCell.m
//  KeerZhineng
//
//  Created by ZJ on 2018/12/24.
//  Copyright © 2018 HY. All rights reserved.
//

#import "HYSelectTimeTableViewCell.h"

@interface HYSelectTimeTableViewCell()

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *btns;

@end

@implementation HYSelectTimeTableViewCell

- (IBAction)btnEvent:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(selectTimeTableViewCell:didClickButtonAtIndex:)]) {
        [self.delegate selectTimeTableViewCell:self didClickButtonAtIndex:sender.tag];
    }
}

- (void)setValues:(NSArray *)values {
    _values = values;
    
    for (UIButton *btn in self.btns) {
        NSString *str = _values[btn.tag];
        if (str.length == 0) {
            str = @"--:--";
        }
        [btn setTitle:str forState:UIControlStateNormal];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
