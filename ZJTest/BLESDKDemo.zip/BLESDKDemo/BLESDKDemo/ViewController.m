//
//  ViewController.m
//  BLESDKDemo
//
//  Created by ZJ on 2019/5/10.
//  Copyright © 2019 HY. All rights reserved.
//

#import "ViewController.h"
#import "HYConnectTableViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) ZJBLEDeviceManager *bleManage;


@end

static NSString *SystemTableViewCell = @"cell";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initAry];
    [self initSettiing];
}

- (void)initAry {
    
}

- (void)initSettiing {
    self.title = @"设备列表";
    self.bleManage = [ZJBLEDeviceManager shareManagerDidUpdateStateHandle:^(ZJDeviceManagerState state) {
        
    }];
    [self.bleManage scanBLEDeviceCompletion:^(NSArray<ZJBLEDevice *> *obj) {
        NSLog(@"扫描回调:%@", obj);
        dispatch_async(dispatch_get_main_queue(), ^{
           [self.tableView reloadData];
        });
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.bleManage.discoveredBLEDevices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:SystemTableViewCell];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SystemTableViewCell];
    }
    ZJBLEDevice *device = self.bleManage.discoveredBLEDevices[indexPath.row];
    cell.textLabel.text = device.name;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    ZJBLEDevice *device = self.bleManage.discoveredBLEDevices[indexPath.row];
    [self.bleManage connectBLEDevice:device completion:^(ZJBLEDevice *device, BOOL connected, NSError *error) {
        if (connected) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
                
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"门锁安全码" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                alert.alertViewStyle = UIAlertViewStyleSecureTextInput;
                UITextField *tf = [alert textFieldAtIndex:0];
                tf.placeholder = @"请输入6位整数";
                tf.keyboardType = UIKeyboardTypeNumberPad;
                tf.textAlignment = NSTextAlignmentCenter;
                [alert show];
            });
        }
    }];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        NSString *text = [alertView textFieldAtIndex:0].text;
        if (text.length == 6) {
            [self.bleManage.connectedBLEDevice operateDataWithType:OperateDataTypeBindDevice parama:[alertView textFieldAtIndex:0].text compltion:^(BOOL success, id value, NSError *error) {
                if (success) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        HYConnectTableViewController *vc = [[HYConnectTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
                        [self showViewController:vc sender:nil];
                    });
                }
            }];
        }
    }
}

@end
