//
//  ZJBLEDevice.m
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJBLEDevice.h"
#import "AES128.h"

@implementation NSData (ZJData)

// 根据范围获取data的值
- (uint32_t)valueWithRange:(NSRange)range {
    Byte *bytes = (Byte *)self.bytes;
    NSUInteger len = range.length;
    uint32_t value = 0;
    for (int i = 0; i < len; i++) {
        NSUInteger offset = 8 * (len-1-i);
        uint32_t v = (bytes[range.location+i] << offset) & (0xff << offset);
        value += v;
    }
    
    return value;
}

/**
 *  十六进制字符串 --> NSData<Byte*>
 */
+ (NSData *)dataWithHexString:(NSString *)hexString {
    NSMutableData *data = [NSMutableData data];
    for (int idx = 0; idx < hexString.length; idx += 2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString *hexStr = [hexString substringWithRange:range];
        NSScanner *scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}

+ (void)valueToBytes:(Byte *)srcBytes value:(uint32_t)value reverse:(BOOL)reverse {
    for (int i = 0; i < 4; i++) {
        if (reverse) {
            srcBytes[3-i] = (value >> 8*(3-i)) & 0xff;
        }else {
            srcBytes[i] = (value >> 8*(3-i)) & 0xff;
        }
    }
}


+ (void)valueToBytes:(Byte *)srcBytes value64:(uint64_t)value reverse:(BOOL)reverse {
    for (int i = 0; i < 8; i++) {
        if (reverse) {
            srcBytes[3-i] = (value >> 8*(8-i)) & 0xff;
        }else {
            srcBytes[i] = (value >> 8*(8-i)) & 0xff;
        }
    }
}

+ (NSData *)timeData:(NSDate *)date reverse:(BOOL)reverse {
    uint32_t time = (uint32_t)[date timeIntervalSince1970];
    Byte bytes[4];
    [NSData valueToBytes:bytes value:time reverse:reverse];
    return [NSData dataWithBytes:bytes length:4];
}

@end

@implementation NSDate (ZJDate)

+ (NSDate *)hy_dateFromString:(NSString *)string
                   withFormat:(NSString *)format {
    
    static NSDateFormatter *dateFormater = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dateFormater = [[NSDateFormatter alloc] init];
    });
    dateFormater.timeZone = [NSTimeZone systemTimeZone];
    dateFormater.locale = [NSLocale autoupdatingCurrentLocale];
    dateFormater.dateFormat = format;
    return [dateFormater dateFromString:string];
}

@end

@implementation NSString (ZJString)

/**
 翻转字符串: abcd-->cdba
 */
- (NSString *)invertByteString {
    NSMutableString *str = [NSMutableString string];
    for (NSUInteger i = self.length; i > 0; i-=2) {
        [str appendString:[self substringWithRange:NSMakeRange(i-2, 2)]];
    }
    return [str mutableCopy];
}

@end

@interface ZJBLEDevice () <CBPeripheralDelegate> {
    Byte *_macBytes;
    Byte *_adsBytes;
}

@property (nonatomic, copy) NSString *mac;
@property (nonatomic, strong) NSData *macData;
@property (nonatomic, strong) NSData *timeData;

@property (nonatomic, strong) CBCharacteristic *writeCT;
@property (nonatomic, strong) CBCharacteristic *notiCT;
@property (nonatomic, strong) CBCharacteristic *readCT;

@property (nonatomic, strong) DeviceDiscoverServiceCompletionHandle discoverServiceCompletion;
@property (nonatomic, strong) OperateCompletionHandle valueCompletion;
@property (nonatomic, assign) OperateDataType operateDataType;
@property (nonatomic, copy) NSString *params;

@end

#define CTWritUUID @"0000FEC7"
#define CTNotiUUID @"0000FEC8"
#define CTReadUUID @"0000FEC9"
#define ServiceUUID @"0000FFE7-1212-EFDE-1523-785FEABCD123"

@implementation ZJBLEDevice

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral {
    return [self initWithPeripheral:peripheral RSSI:nil];
}

- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral RSSI:(NSNumber *)rssi {
    self = [super init];
    if (self) {
        [self initSettingWithPeriphera:peripheral];
    }
    
    return self;
}

- (void)initSettingWithPeriphera:(CBPeripheral *)peripheral {
    _peripheral = peripheral;
    _peripheral.delegate = self;
    _name = peripheral.name;
    NSArray *compons = [_name componentsSeparatedByString:@"-"];
    if (compons.count == 2) {
        self.mac = compons[1];
        self.macData = [NSData dataWithHexString:[self.mac invertByteString]];
        _macBytes = (Byte *)self.macData.bytes;
    }
}

- (void)setManufacturerData:(NSData *)manufacturerData {
    _manufacturerData = manufacturerData;
    
    _adsBytes = (Byte *)_manufacturerData.bytes;
}

- (void)discoverServicesCompletion:(DeviceDiscoverServiceCompletionHandle)completion {
    self.discoverServiceCompletion = completion;
    [self.peripheral discoverServices:@[[CBUUID UUIDWithString:ServiceUUID]]];
}

- (void)operateDataWithType:(OperateDataType)type parama:(NSString *)params compltion:(OperateCompletionHandle)completion {
    self.operateDataType = type;
    self.valueCompletion = completion;
    self.params = params;
    
    Byte bytes[19] = {0xaa};
    Byte srcValueBytes[16];
    if (type == OperateDataTypeBindDevice) {
        srcValueBytes[0] = 0x02;
    }else if (type == OperateDataTypeOpenDoor) {
        srcValueBytes[0] = 0x03;
    }
    int offset = 1;
    for (int i = offset; i < 16; i++) {
        if (i < offset + params.length) {
            // ints转bytes
            Byte desBytes[4];
            [NSData valueToBytes:desBytes value:[params substringWithRange:NSMakeRange(i-offset, 1)].intValue + 48 reverse:NO];
            srcValueBytes[i] = desBytes[3];
        }else {
            srcValueBytes[i] = 0x00;
        }
    }
    NSLog(@"bind = %@", [NSData dataWithBytes:srcValueBytes length:16]);
    [self encryptCommand:srcValueBytes endCommandBytes:bytes];
    NSLog(@"data = %@", [NSData dataWithBytes:bytes length:19]);
    [self.peripheral writeValue:[NSData dataWithBytes:bytes length:sizeof(bytes)/sizeof(Byte)] forCharacteristic:self.writeCT type:CBCharacteristicWriteWithResponse];
}

- (void)writeWithData:(NSData *)data type:(CBCharacteristicWriteType)type {
    if (self.writeCT) {
        [self.peripheral writeValue:data forCharacteristic:self.writeCT type:type];
    }
}

#pragma mark - CBPeripheralDelegate

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(nullable NSError *)error {
    NSLog(@"-->services = %@", peripheral.services);
    
    for (CBService *sev in peripheral.services) {
        [peripheral discoverCharacteristics:nil forService:sev];
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    NSLog(@"-->characteristics = %@", service.characteristics);
    
    for (CBCharacteristic *ct in service.characteristics) {
        if ([ct.UUID.UUIDString hasPrefix:CTWritUUID]) {
            self.writeCT = ct;
        }else if ([ct.UUID.UUIDString hasPrefix:CTNotiUUID]) {
            self.notiCT = ct;
            [peripheral setNotifyValue:YES forCharacteristic:self.notiCT];
        }else if ([ct.UUID.UUIDString hasPrefix:CTReadUUID]) {
            self.readCT = ct;
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error {
    NSLog(@"%s, %@", __func__, error);
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error {
    NSLog(@"%s", __func__);
    NSLog(@"characteristic = %@, len = %lu", characteristic, characteristic.value.length);
    
    NSData *data = characteristic.value;
    Byte *bytes = (Byte *)data.bytes;
    if (data.length) {
        Byte desBytes[16];
        [self decipheringValue:bytes desBytes:desBytes];
        if (desBytes[0] == 0x01 && desBytes[1] == 0xe0) {   // 握手
            self.discoverServiceCompletion(error);
        }else {
            if (desBytes[1] == 0xe0) {
                if(self.operateDataType == OperateDataTypeBindDevice) {
                    self.valueCompletion(YES, characteristic.value, error);
                }
            }
        }
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error {
    NSLog(@"%s, %@", __func__, characteristic);
    
    if (self.writeCT) {
        [self shakeHand];
    }
}

/**
 握手
 */
- (void)shakeHand {
    self.timeData = [NSData timeData:[NSDate date] reverse:YES];

    Byte bytes[19] = {0xaa};
    Byte *timeBytes = (Byte *)self.timeData.bytes;
    NSLog(@"macBytes = %@, timeBytes = %@", self.macData, self.timeData);
    
    int offset = 1;
    Byte srcValueBytes[16] = {0x01};
    for (int i = offset; i < 16; i++) {
        if (i < offset + self.macData.length) {
            srcValueBytes[i] = _macBytes[i-offset];
        }else if(i < offset + self.macData.length + self.timeData.length) {
            srcValueBytes[i] = timeBytes[i-offset-self.macData.length];
        }else {
            srcValueBytes[i] = 0x00;
        }
    }
    
    [self encryptCommand:srcValueBytes endCommandBytes:bytes];

    NSLog(@"data = %@, len = %lu", [NSData dataWithBytes:bytes length:19], sizeof(bytes)/sizeof(Byte));
    [self.peripheral writeValue:[NSData dataWithBytes:bytes length:sizeof(bytes)/sizeof(Byte)] forCharacteristic:self.writeCT type:CBCharacteristicWriteWithResponse];
}

#pragma mark - private

- (void)getValueBytes:(Byte *)srcBytes desBytes:(Byte *)desBytes {
    for (int i = 1; i < 17; i++) {
        desBytes[i-1] = srcBytes[i];
    }
}

- (void)bytes2Ints:(Byte *)src ints:(int *)des len:(int)len {
    for (int i = 0; i < len; i++) {
        des[i] = src[i];
    }
}

- (void)ints2Bytes:(int *)src bytes:(Byte *)des len:(int)len {
    for (int i = 0; i < len; i++) {
        Byte bytes[4];
        [NSData valueToBytes:bytes value:src[i] reverse:NO];
        des[i] = bytes[3];
    }
}

#pragma mark - 加密、解密

- (void)encryptCommand:(Byte *)srcValueBytes endCommandBytes:(Byte *)endByes {
    // bytes转ints
    int srcValueInts[16];
    int desValueInts[16];
    [self bytes2Ints:srcValueBytes ints:srcValueInts len:16];
    NSLog(@"srcValueBytes = %@", [NSData dataWithBytes:srcValueBytes length:16]);
    
    for (int i = 0; i < 16; i++) {
        NSLog(@"srcValueInts[%d] = %x, len = %lu", i, srcValueInts[i], sizeof(srcValueInts[i]));
    }
    
    AES_DEAL(srcValueInts, desValueInts, 1, _adsBytes[2], _adsBytes[3], _macBytes);
    
    // ints转bytes
    Byte desBytes[16];
    [self ints2Bytes:desValueInts bytes:desBytes len:16];
    for (int i = 0; i < 16; i++) {
        NSLog(@"desBytes[%d] = %x, len = %lu", i, desBytes[i], sizeof(desBytes[i]));
    }
    
    for (int i = 1; i < 17; i++) {
        endByes[i] = desBytes[i-1];
    }
    
    endByes[17] = [self CRCValue:desBytes range:NSMakeRange(0, 16)];
    endByes[18] = 0x55;
}

// 解密
- (void)decipheringValue:(Byte *)bytes desBytes:(Byte *)desBytes {
    Byte srcBytes[16];
    [self getValueBytes:bytes desBytes:srcBytes];
    
    // bytes转ints
    int srcValueInts[16];
    int desValueInts[16];
    [self bytes2Ints:srcBytes ints:srcValueInts len:16];
    AES_DEAL(srcValueInts, desValueInts, 0, _adsBytes[2], _adsBytes[3], _macBytes);
    
    // ints转bytes
    [self ints2Bytes:desValueInts bytes:desBytes len:16];
    NSLog(@"desBytes = %@", [NSData dataWithBytes:desBytes length:16]);
}

/**
 校验和
 */
- (Byte)CRCValue:(Byte *)bytes range:(NSRange)range {
    Byte tempByte = 0x00;
    for (NSUInteger i = range.location; i < range.length+range.location; i++) {
        if (i == range.location) {
            tempByte = bytes[i];
        }else {
            tempByte = tempByte ^ bytes[i];
        }
    }
    return tempByte;
}

@end
