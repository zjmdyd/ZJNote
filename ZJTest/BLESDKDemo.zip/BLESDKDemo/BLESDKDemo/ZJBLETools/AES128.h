
#include <stdint.h>
#include <string.h>



extern const uint8_t Radio_pool[40][2];


void aes(int*, int*, int*, int);
void aes_detail(int[4][4], int[4][4], int);
void subBytes(int [4][4], int);
void shiftRows(int [4][4], int);
void mixColumns(int [4][4], int);
void addRoundKey(int [4][4], int[4][4]);
int aes_multiple(int, int);
void keyExpansion(int key[4][4], int w[11][4][4]);
extern void Extract_key0_key1(unsigned char Radio_0,unsigned char Radio_1,unsigned char * Chip_ID_s);

void AES_TEXT(void);

void miyao_generate(uint8_t *p_ble_door_key,
                                uint8_t *p_ble_mac,
                                uint8_t *p_valid_time,
                                uint32_t timestamp,
                                uint8_t *p_miyao_o);


void AES_DEAL(int* source_path, int* des_path,int method,unsigned char Radio_0,unsigned char Radio_1,unsigned char * Chip_ID_s);








