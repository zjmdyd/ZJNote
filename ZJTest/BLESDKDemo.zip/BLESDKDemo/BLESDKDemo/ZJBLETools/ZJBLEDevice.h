//
//  ZJBLEDevice.h
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSInteger, OperateDataType) {
    OperateDataTypeBindDevice,      // 绑定设备
    OperateDataTypeOpenDoor,        // 密码开门
};

typedef void(^DeviceDiscoverServiceCompletionHandle)(NSError *error);
typedef void(^OperateCompletionHandle)(BOOL success, id value, NSError *error);

@interface ZJBLEDevice : NSObject

- (instancetype)init NS_UNAVAILABLE;

/**
 *  每个BLEDevice对象对应一个peripheral
 */
- (instancetype)initWithPeripheral:(CBPeripheral *)peripheral;

/**
 *  Pointer to CoreBluetooth peripheral
 */
@property (nonatomic, strong, readonly) CBPeripheral *peripheral;
@property (nonatomic, copy, readonly) NSString *name;
@property (nonatomic, strong) NSData *manufacturerData;

@property (nonatomic, assign) BOOL hasDoubleConfirm;    // 双重认证
@property (nonatomic, assign) BOOL hasChannelMode;      // 通道模式

- (void)discoverServicesCompletion:(DeviceDiscoverServiceCompletionHandle)completion;
- (void)operateDataWithType:(OperateDataType)type parama:(NSString *)params compltion:(OperateCompletionHandle)completion;

@end
