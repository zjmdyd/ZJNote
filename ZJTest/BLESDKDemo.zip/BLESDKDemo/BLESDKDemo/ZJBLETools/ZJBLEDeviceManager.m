//
//  ZJBLEDeviceManager.m
//  ZJFramework
//
//  Created by ZJ on 1/26/16.
//  Copyright © 2016 ZJ. All rights reserved.
//

#import "ZJBLEDeviceManager.h"
#import "ZJBLEDevice.h"

@interface CBPeripheral (ZJPeripheral)

- (BOOL)isEqual:(CBPeripheral *)peripheral;

@end

@implementation CBPeripheral (ZJPeripheral)

- (BOOL)isEqual:(CBPeripheral *)peripheral {
    return [self.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString];
}

@end

@interface ZJBLEDeviceManager ()<CBCentralManagerDelegate> 

@property (nonatomic, strong) CBCentralManager *centralManager;
@property (nonatomic, strong) BLERefreshStateCompletionHandle stateCompletion;
@property (nonatomic, strong) BLEScanCompletionHandle scanCompletion;
@property (nonatomic, strong) BLEConnectCompletionHandle connectCompletion;
@property (nonatomic, strong) BLEConnectCompletionHandle disConnectCompletion;

@end

#define DevicePrefix @"a-"

static ZJBLEDeviceManager *_manager = nil;

@implementation ZJBLEDeviceManager

@synthesize state = _state;

- (instancetype)init {
    self = [super init];
    if (self) {
        [self initSetting];
    }
    
    return self;
}

- (void)initSetting {
    self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0) options:@{CBPeripheralManagerOptionShowPowerAlertKey: @(YES)}];
}

+ (instancetype)shareManager {
    if (!_manager) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _manager = [[ZJBLEDeviceManager alloc] init];
        });
    }
    
    return _manager;
}

+ (instancetype)shareManagerDidUpdateStateHandle:(BLERefreshStateCompletionHandle)completion {
    if (!_manager) {
        _manager = [ZJBLEDeviceManager shareManager];
    }
    _manager.stateCompletion = completion;
    
    return _manager;
}

- (void)scanBLEDeviceCompletion:(BLEScanCompletionHandle)completion {
    self.scanCompletion = completion;
    
    if (self.centralManager.state == CBCentralManagerStatePoweredOn) {
        [self beganScan];
    }
}

- (void)beganScan {
    [self.centralManager scanForPeripheralsWithServices:nil options:nil];
}

- (void)connectBLEDevice:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion {
    self.connectCompletion = completion;
    [self.centralManager connectPeripheral:device.peripheral options:nil];
}

- (void)cancelBLEDeviceConnection:(ZJBLEDevice *)device completion:(BLEConnectCompletionHandle)completion {
    [self.centralManager cancelPeripheralConnection:device.peripheral];
}

#pragma mark - CBCentralManagerDelegate

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    NSLog(@"%s, state = %ld", __func__, (long)central.state);
    if (self.stateCompletion) {
        self.stateCompletion((ZJDeviceManagerState)central.state);
    }
    if (central.state == CBCentralManagerStatePoweredOn) {
        [self beganScan];
    }
}

/**
 *  发现设备
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
    if (![peripheral.name hasPrefix:DevicePrefix]) return;
    
    NSLog(@"发现设备--->%@", advertisementData);
    
    NSMutableArray *ary = [NSMutableArray arrayWithArray:self.discoveredBLEDevices];
    for (int i = 0; i < ary.count; i++) {
        ZJBLEDevice *device = ary[i];
        if ([device.peripheral.name isEqual:peripheral.name]) {
            [ary removeObject:device];
            break;
        }
    }

    ZJBLEDevice *device = [[ZJBLEDevice alloc] initWithPeripheral:peripheral];
    device.manufacturerData = advertisementData[@"kCBAdvDataManufacturerData"];
    [ary addObject:device];
    _discoveredBLEDevices = [ary copy];
    
    /**
     *  不管是用户手动扫描还是automScan,都用scanCompletion回调
     */
    if (self.scanCompletion) {
        self.scanCompletion(_discoveredBLEDevices);
    }
}

/**
 *  已连接
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    NSLog(@"%s", __func__);
    NSMutableArray *discoverAry = [NSMutableArray arrayWithArray:self.discoveredBLEDevices];
    _connectedBLEDevice = nil;
    
    ZJBLEDevice *device;
    for (int i = 0; i < discoverAry.count; i++) {
        device = discoverAry[i];
        if ([device.peripheral isEqual:peripheral]) {
            [discoverAry removeObject:device];
            _connectedBLEDevice = device;
            break;
        }
    }
    _discoveredBLEDevices = [discoverAry copy];

    [_connectedBLEDevice discoverServicesCompletion:^(NSError *error) {
        if (!error) {
            if (self.connectCompletion) {
                self.connectCompletion(device, YES, nil);
            }
        }
    }];
}

/**
 *  断开连接
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"%s, error = %@", __func__, error);
    
    if ([self.connectedBLEDevice.peripheral isEqual:peripheral]) {
        /**
         *  当有disconnectCompletion就用disconnectCompletion回调, 否则用connectionCompletion回调
         */
        if (self.disConnectCompletion) {
            self.disConnectCompletion(self.connectedBLEDevice, NO, error);
        }else if (self.connectCompletion) {
            self.connectCompletion(self.connectedBLEDevice, NO, error);
        }
        //        _connectedBLEDevice = nil;
    }
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"%s, error = %@", __func__, error);
    ZJBLEDevice *device;
    for (int i = 0; i < self.discoveredBLEDevices.count; i++) {
        ZJBLEDevice *tempDevice = self.discoveredBLEDevices[i];
        if ([tempDevice.peripheral isEqual:peripheral]) {
            device = tempDevice;
            break;
        }
    }
    
    if (self.connectCompletion) {
        self.connectCompletion(device, NO, error);
    }
}

#pragma mark - public

- (void)rescan {
    if (_discoveredBLEDevices.count) {
        _discoveredBLEDevices = @[];
        if (self.scanCompletion) {
            self.scanCompletion(_discoveredBLEDevices);
        }
    }
    
    [self beganScan];
}

- (void)stopScan {
    [self.centralManager stopScan];
}

- (void)reset {
    _discoveredBLEDevices = @[];
    self.scanCompletion = nil;
    self.stateCompletion = nil;
    self.disConnectCompletion = nil;
}

#pragma mark - getter

- (ZJDeviceManagerState)state {
    _state = (ZJDeviceManagerState)self.centralManager.state;
    return _state;
}

@end
